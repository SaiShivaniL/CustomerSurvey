//import logo from './logo.svg';
import './App.css';
import { createBrowserHistory } from 'history';
import FrontPage from './components/frontpage/frontpage';
import LoginPage from './components/login/login';
import RegisterPage from './components/register/register';
import ForgotPage from './components/login/forgot';
import OTPPage from './components/login/otp';
import UpdatePage from './components/login/update';
import {BrowserRouter as Router,Switch,Route} from "react-router-dom";
import HomePage from './components/login/homepage';
function App() {
  const history=createBrowserHistory()
  return (
    <div className="page">
      <Router history={history}>
        <Switch>
          <Route exact path="/"><FrontPage/></Route>
          <Route path="/login"><LoginPage /></Route>
          <Route path="/register"><RegisterPage /></Route>
          <Route path="/homepage"><HomePage /></Route>
        </Switch>
      </Router>
  
    </div>
  );
}
//<LoginPage />
//<RegisterPage />
//<FrontPage />
//  <ForgotPage />
//<UpdatePage />
export default App;
