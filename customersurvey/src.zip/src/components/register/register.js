import React ,{useState} from "react";
import "./register.css"
import axios from "axios"
import {useHistory} from "react-router-dom";

const RegisterPage = () => {
    const history=useHistory()
    const [user ,setUser]=useState({
        id:"",
        email:"",
        password:"",
        reEnterPassword:""
    })
    const handleChange = e=>{
        const {name,value}=e.target;
        setUser({
            ...user,
            [name]:value
        })
        console.log(name,value)
    }
    const register = ()=>{
        const {id,email,password,reEnterPassword}=user
        var d=/\d/
        var W=/[A-Z]/
        var w=/[a-z]/
        var idx=/[cd]\d/
        var emx=/Ww/
        if(id && email && password){
            if(id.length==7 && idx.test(id)){
                if(d.test(password) && W.test(password) && W.test(password) && password.length>=8){
                 if(emx.test(email)){   
                if(password===reEnterPassword){
                alert("posted!")
            /*axios.post("http://localhost:5055/register",user)
            .then(res=> alert(res.data.message))
            history.push("/login")*/
        }
        else{
            alert("Passwords did not match!!")
        }
    }else{
        alert("enter valid email")
    }
    }
    else{
        alert("Password should have 1 number 1 capital 1 small alphabet and the length of password should be greater than 8")
    }
    }else{alert("ID length should be equal to 7 and should start with d or c ")}
}
else{
            alert("All Fields are required!!")
        }
    }
    return (
        <div className="cover">
            {console.log("User",user)}
            <div className='box'>
                <img src="telstralogo.jpg" alt="logo" height="100px" width="250px"/>
            </div>
          
            <h1>Registration</h1>
            <input type="text" name="id" value={user.id} placeholder="Employee Id" onChange={handleChange}/>
            <input type="text" name="email" value={user.email} placeholder="Employee Mail" onChange={handleChange}/>
            <input type="password" name="password" value={user.password} placeholder="password" onChange={handleChange} />
            <input type="password" name="reEnterPassword" value={user.reEnterPassword} placeholder=" Re enter password" onChange={handleChange} /><br></br>

            <button className="login-btn" onClick={register}>SignUp</button>  
            or
            <button className="login-btn" onClick={()=>history.push("/login")}>Login</button>       

        </div>
    )
}

export default RegisterPage