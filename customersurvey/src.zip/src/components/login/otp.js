import React,{useState} from "react";
import "./login.css"
//import axios from "axios";

const OTPPage = () => {
   /* const login=()=>{
        axios.post("http://localhost:5055/login",user)
        .then(res=>alert(res.data.message))
    }*/
    return (
        <div className="cover">
            <div className='box'>
                <img src="telstralogo.jpg" alt="logo" height="100px" width="250px"/>
            <br></br><br></br><br></br>
            <h1>Enter OTP</h1>
            <br></br><br></br>
            <input type="text" name="otp" placeholder="Enter OTP Received" />
            <br></br>
            <button className="login-btn">Submit </button>  
            <br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br>    
            </div>
        </div>
    )
}

export default OTPPage