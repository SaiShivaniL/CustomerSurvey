import React,{useState} from "react";
import "./login.css"
import axios from "axios";
import { useHistory } from "react-router-dom";

const LoginPage = () => {
    const history=useHistory()
    const [user ,setUser]=useState({
        id:"",
        password:""
        })
    const handleChange = e=>{
        const {name,value}=e.target;
        setUser({
            ...user,
            [name]:value
        })
        console.log(name,value)
    }
    const regis=()=>{
        history.push("/register")
    }
    const login=()=>{
        axios.post("http://localhost:5055/login",user)
        .then(res=>alert(res.data.message))
        history.push("/homepage")
    }
    return (
        <div className="cover">
            {console.log("User",user)}
            <div className='box'>
                <img src="telstralogo.jpg" alt="logo" height="100px" width="250px"/>
            </div>
          
            <h1>Login</h1>
            <input type="text" name="id" value={user.id} placeholder="Employee Id" onChange={handleChange} />
            <input type="password" name="password" value={user.password} placeholder="password" onChange={handleChange} />

            <button className="login-btn" onClick={login}>Login</button>

        
            <a href="https://www.google.com/">Forget password?</a>   
            <button className="login-btn" onClick={regis}>SignUp</button>       

        </div>
    )
}

export default LoginPage