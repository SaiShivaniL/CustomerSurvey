import React from "react";
import "./login.css";
const HomePage = () => {
   
    return (
       
       <div className="cover">
            <button className="survey-btn">Survey/Feedback</button>
            <button className="survey-btn">Polls</button>
        </div>              
           
       
    )
}
export default HomePage