import React,{useState} from "react";
import "./login.css"
//import axios from "axios";

const UpdatePage = () => {
   /* const login=()=>{
        axios.post("http://localhost:5055/login",user)
        .then(res=>alert(res.data.message))
    }*/
    return (
        <div className="cover">
            <div className='box'>
                <img src="telstralogo.jpg" alt="logo" height="100px" width="250px"/>
            <br></br>
            <h1>Enter OTP</h1>
            <br></br><br></br>
            <input type="text" name="email" placeholder="Enter email" />
            <input type="text" name="password" placeholder="New password" />
            <input type="text" name="reEnterPassword" placeholder="Re Enter Password" />
            <br></br><br></br>
            <button className="login-btn">Submit </button>  
            <br></br><br></br><br></br><br></br><br></br><br></br> 
            </div>
        </div>
    )
}

export default UpdatePage