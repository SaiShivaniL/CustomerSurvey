import React,{useState} from "react";
import "./login.css"
//import axios from "axios";

const ForgotPage = () => {
   /* const login=()=>{
        axios.post("http://localhost:5055/login",user)
        .then(res=>alert(res.data.message))
    }*/
    return (
        <div className="cover">
            <div className='box'>
                <img src="telstralogo.jpg" alt="logo" height="100px" width="250px"/>
            <br></br><br></br><br></br>
            <h1>Forgot password</h1>
            <br></br><br></br>
            <input type="text" name="email" placeholder="Enter email for otp" />
            <br></br>
            <button className="login-btn">Send OTP</button>  
            <br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br>    
            </div>
        </div>
    )
}

export default ForgotPage