import React from 'react'
import "./frontpage.css"
import {useHistory} from "react-router-dom";


const FrontPage = () => {
   const history=useHistory()
    return ( 
        <div className="cover">
            <div className='box'>
                <img src="telstralogo.jpg" alt="logo" height="150px" width="250px"/>
            </div>
            
            <button className="login-btn" onClick={()=>history.push("/login")}>Employee</button>

            <button className="login-btn" onClick={()=>history.push("/homepage")}>Customer</button>
        </div>
    )
}

export default FrontPage